#ifndef PHASING_H
#define PHASING_H

// functions
int PhasingMain(int argc, char** argv);

// options
void PhasingOptions(int argc, char** argv);

#endif