#ifndef HAPLOTAG_H
#define HAPLOTAG_H

// functions
int HaplotagMain(int argc, char** argv);

// options
void HaplotagOptions(int argc, char** argv);

#endif